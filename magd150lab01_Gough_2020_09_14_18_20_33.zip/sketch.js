function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(140);

  rectMode(CORNERS);
  noFill();
  rect(50, 100, 350, 350); //base of house

  rectMode(CORNERS);
  fill(40);
  rect(200, 250, 250, 350); //door
  
  rectMode(CORNERS);
  fill(230);
  rect(95, 250, 135, 290); //bottom left window
  
  rectMode(CORNERS);
  fill(230);
  rect(95, 140, 135, 180); //top left window
  
  rectMode(CORNERS);
  fill(230);
  rect(265, 140, 305, 180); //top right window

  line(50, 100, 200, 10);
  line(350, 100, 200, 10); //both lines represent the roof
  
  line(115, 250, 115, 290);
  line(95, 270, 135, 270); //both for bottom left window
  
  line(115, 140, 115, 180);
  line(95, 160, 135, 160); //both for top left window
  
  line(285, 140, 285, 180);
  line(265, 160, 305, 160); //both for top right window
  
  line(50, 100, 30, 120);
  line(350, 100, 370, 120); //both lines represent overhangs

  point(95, 250);
  point(135, 290); //sets general location for window

  ellipseMode(RADIUS);
  fill(255);
  ellipse(235, 305, 10, 10);
  
  ellipseMode(CENTER);
  fill(40);
  ellipse(235, 305, 9, 9); // both ellipses represent door knob
}