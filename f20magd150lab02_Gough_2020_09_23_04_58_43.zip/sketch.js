function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(50);
  
  let a = color(255, 150, 100);
  arc(100, 100, 70, 70, 0, TWO_PI);
  fill(a); //suppose to be the moon
  
  let b = color('blue');
  arc(300, 125, 80, 80, 0, TWO_PI);
  fill(b); //mars
  
  let c = color('000000');
  arc(400, 50, 70, 70, 0, TWO_PI);
  fill(c);  //neptune
  
  fill(160);
  quad(150, 400, 350, 400, 350, 430, 150, 430);
  triangle(175, 400, 250, 325, 325, 400);
  line(150, 415, 50, 415);
  line(350, 415, 450, 415);
  line(130, 350, 130, 470);
  line(100, 350, 100, 470);
  line(70, 350, 70, 470);
  line(370, 350, 370, 470);
  line(400, 350, 400, 470);
  line(430, 350, 430, 470); //all represents satallite
  
  
  point(200, 200);
  point(80, 220);
  point(300, 360);
  point(265, 265);
  point(450, 200);
  point(430, 275);  //all points suppose to represent stars
  strokeWeight(10);
}