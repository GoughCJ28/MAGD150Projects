var a = 350;
var b = 300;
var c = 50;
var d = 450;
var e = 400; //all variables are for the red and/or brown circles that represent pepperoni and/or sausage

function setup() {
  createCanvas(800, 800);
  background(80);
 
}

function draw() {
  
  ellipse(400, 350, 250, 250);
  fill(255, 215, 0); //cheese base
  
  line(400, 225, 400, 475);
  line(275, 350, 525, 350); // slices on the pizza
  
  push();
  if (mouseX >= 400) {
  fill(255, 255, 102); // banana peppers
} else {
  fill(255); //ranch
}
  ellipse(mouseX, 665, 50, 50);
  pop();
  
  push();
  if (mouseY <=350) {
    fill(65, 43, 21); //BBQ
  } else {
    fill(139, 0, 0); // red pepper
  }
  ellipse(500, mouseY, 50, 50);
  ellipse(300, mouseY, 50, 50);
  pop();
  
  push();
  if (mouseX >= 275 && mouseX <= 525) {
    fill(165, 42, 42); // sausage
  } else {
    fill (255, 0, 0);  // pepperoni
  }
  ellipse(a, b, c, c);
  ellipse(d, b, c, c);
  ellipse(a, e, c, c);
  ellipse(d, e, c, c);
pop();                  // if mouse is on, directly above, or directly below pizza, red ellipses become brown
}
  
function mousePressed() {
  if(mouseIsPressed) {
    fill(0, 150, 0);  // green pepper
  }
    ellipse(600, 600, 50, 50);
    ellipse(50, 115, 50, 50);
    ellipse(50, 750, 50, 50);
  
}

function keyPressed() {
  if(keyIsPressed) {
    fill(160, 112, 45); // mushrooms
    ellipse(145, 465, 50, 50);
    ellipse(750, 50, 50, 50);
    ellipse(400, 125, 50, 50);
  }
}