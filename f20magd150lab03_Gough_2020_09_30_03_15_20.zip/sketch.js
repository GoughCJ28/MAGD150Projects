function setup() {
  createCanvas(600, 600);
  frameRate(5); // A higher frame rate is too fast for what i'm doing. I hope it makes sense to you.
  textSize(30);

}

function draw() {
  background(0, 230, 255); // light blue to make it look like bubbles are in the sky
  text(frameCount, width-280, height-10); //puts frameCount in the bottom center of the sketch
  max(50, 450);
  min(50, 450);
  let a = 50;
  let b = 25;
  float(a);
  float(b);
  print(a);
  print(b);
  
  ellipse(mouseX, 100, 100, 100);
  ellipse(100, pmouseY, 100, 100);
  ellipse(pmouseX, 250, 100, 100);
  ellipse(305, pmouseY, 100, 100);
  ellipse(mouseX, 330, a+=50, 100);
  ellipse(380, mouseY, b*=4, 100);
  ellipse(mouseX, mouseY, 100, 100); // all ellipsies represent 1 bubble
  
  dist(width/1.5, height/1.5, mouseX, mouseY);
  
  noFill();
  strokeWeight(2); 
}