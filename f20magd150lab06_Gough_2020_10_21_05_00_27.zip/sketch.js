var pacX, pacY, pacRad

function setup() {
  createCanvas(900, 800);
  
  pacX = 50;
  pacY = height/10;
  pacRad = 100;
  ticTacX = 20
  ticTacY = 30
}

function draw() {
  background(0);
  
  if(keyIsDown(LEFT_ARROW) || keyIsDown(65)) {
    pacX -= 3;
  }
  if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) {
    pacX += 3;
  }
  if (keyIsDown(UP_ARROW) || keyIsDown(87)) {
    pacY -=3;
  }
  if (keyIsDown(DOWN_ARROW) || keyIsDown(83)) {
    pacY += 3     // All key commands are to move pacman around. You have to click on the canvas to move pacman.
  }
  
  
  drawPacMan();
  drawMaze();
  drawTicTacs();
}
  
  function drawPacMan() {
    
    fill('yellow');
    arc(pacX, pacY, pacRad, pacRad, radians(15), radians(345), PIE);
    fill(0);
    ellipse(pacX+20, pacY-20, 10, 10);
  }

  function drawMaze() {
  push();
  stroke(255); //I attempted to make a maze for pac-man to go through. I apologize for the amount of lines, but it's what had to be done for the maze.
  line(0, 20, 900, 20);
  line(0, 140, 250, 140);
  line(400, 140, 700, 140);
  line(800, 140, 900, 140);
  line(250, 140, 250, 300);
  line(400, 140, 400, 450);
  line(700, 140, 700, 450);
  line(800, 140, 800, 450);
  line(250, 300, 0, 300);
  line(400, 450, 130, 450);
  line(700, 450, 900, 450);
  line(0, 580, 770, 580);
  line(550, 580, 550, 270);
  line(900, 750, 110, 700);
  pop();
    //CHALLENGE: try to make it through without touching any lines
    
    fill('lime');
    a = "end of the maze. congrats!";
    textSize(20);
    text(a, 10, 780);
  }

function drawTicTacs() {
  
  push();
  stroke(255);
  strokeWeight(15);
  point(405, 80);
  translate(405, 80);
  rotate(PI / 13.0);
  point(-50, 150);
  pop();
  
  push();
  stroke(255);
  strokeWeight(15);
  point(70, 700);
  scale(1.2, 1.0);
  point(70, 700);
  pop();
  
  push();
  stroke(255);
  strokeWeight(15);
  point(150, 80);
  point(650, 80);
  point(850, 80);
  point(170, 380);
  point(170, 515);
  point(470, 380);
  point(550, 215);
  point(840, 580);
  point(400, 650);
  pop();
  // CHALLENGE: "collect" all the tic tacs
}
